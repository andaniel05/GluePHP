<?php

require_once 'bootstrap.php';

use Andaniel05\GluePHP\Request\Request;
use function Opis\Closure\{serialize as s, unserialize as u};

// Obtiene la instancia de la app persistida por el controlador de carga o por
// el procesamiento anterior.
session_start();
$app = u($_SESSION['app']);

// La app procesa la solicitud y devuelve una respuesta.
$request = Request::createFromJSON($_REQUEST['glue_request']);
$response = $app->handle($request);

// Hack para corregir un bug de opis. Será eliminado próximamente.
(function ($dispatcher) {
    $dispatcher->sorted = [];
})->call($app->getDispatcher());

// Vuelve a persistir la app.
$_SESSION['app'] = s($app);

// Envía al navegador la respuesta en formato JSON.
echo $response->toJSON();
die();
