en: Minimum PHP version required is 7.1.1
es: La versión mínima requerida de PHP es la 7.1.1